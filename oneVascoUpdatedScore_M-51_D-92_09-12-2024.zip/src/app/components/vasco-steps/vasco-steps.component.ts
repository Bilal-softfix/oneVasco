import { Component } from '@angular/core';

@Component({
  selector: 'app-vasco-steps',
  imports: [],
  templateUrl: './vasco-steps.component.html',
  styleUrl: './vasco-steps.component.css'
})
export class VascoStepsComponent {
  vascoWork = 'src/assets/vasco-works (1).webp'
}
