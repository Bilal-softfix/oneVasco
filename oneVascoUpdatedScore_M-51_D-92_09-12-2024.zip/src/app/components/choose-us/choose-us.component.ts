import { Component } from '@angular/core';

@Component({
  selector: 'app-choose-us',
  imports: [],
  templateUrl: './choose-us.component.html',
  styleUrl: './choose-us.component.css'
})
export class ChooseUsComponent {

}
